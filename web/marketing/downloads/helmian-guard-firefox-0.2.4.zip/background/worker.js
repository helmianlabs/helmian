// The extension's background service worker.
//
// It exists because the checking has to happen somewhere that can load ES
// modules, and a Chrome content script cannot. The worker imports the copied
// Helmion modules and answers three messages:
//
//   helmion:scan    code blocks in, per-block destructive-command verdicts out
//   helmion:claims  prose in, per-passage unsourced-claim findings out
//   helmion:badge   set the toolbar badge for the tab that asked
//
// THE BADGE BELONGS TO helmion:scan ALONE. A red count means somebody handed
// Troy a command that would destroy something. Unsourced claims are advisory,
// they are wrong often enough that their own source file lists the ways, and
// letting them light the same indicator would teach him to ignore it. They are
// drawn beside the sentence they are about and nowhere else.
//
// Nothing here touches the network and nothing here calls a model. Phase 1 is a
// regular expression run against text, on this machine, and that is all.
//
// It is also the seam for later phases: when the local model verifier arrives,
// it plugs in here and the content script does not change. The claim detector's
// own two-stage design expects exactly that — every finding it returns carries
// `needsLookup` and the extracted referent so a stage two can check ONE claim
// instead of a whole reply.

import { scanBlocks } from './scan.js';
import { scanProse } from './claims.js';
import {
  getUploadSettings,
  setUploadSettings,
  uploadNewFindings,
} from './upload.js';
import {
  appendEntry,
  chromeStorage,
  clearLedger,
  exportBundle,
  ledgerStats,
  makeEntry,
  readLedger,
} from './ledger.js';

// The one place the storage permission is used.
const ledger = chromeStorage();

const RED = '#b3261e';
const AMBER = '#c77700';
const BLUE = '#4a5b7a';

let latestStatus = {
  protection: 'unknown',
  claims: 'unknown',
};

function setBadge(tabId, info) {
  if (typeof tabId !== 'number') return;
  try {
    if (info.broken) {
      chrome.action.setBadgeText({ tabId, text: '!' });
      chrome.action.setBadgeBackgroundColor({ tabId, color: AMBER });
      chrome.action.setTitle({ tabId, title: 'Helmion Guard needs attention — open for details' });
      return;
    }
    const dangerous = Number(info.dangerous) || 0;
    if (dangerous > 0) {
      chrome.action.setBadgeText({ tabId, text: String(dangerous) });
      chrome.action.setBadgeBackgroundColor({ tabId, color: RED });
      chrome.action.setTitle({
        tabId,
        title: `Helmion Guard flagged ${dangerous} destructive code block(s) on this page`,
      });
      return;
    }
    if (info.degraded) {
      chrome.action.setBadgeText({ tabId, text: '•' });
      chrome.action.setBadgeBackgroundColor({ tabId, color: BLUE });
      chrome.action.setTitle({ tabId, title: 'Helmion Guard is active — open for status' });
      return;
    }
    chrome.action.setBadgeText({ tabId, text: '' });
    chrome.action.setTitle({ tabId, title: 'Helmion Guard is watching this page' });
  } catch (error) {
    // A tab that closed mid-flight is not a failure worth surfacing.
    console.warn('[Helmion Guard] badge update failed:', error.message);
  }
}

// Three messages hand back, or destroy, the whole conversation ledger — the
// excerpts of the user's chats this extension keeps as evidence. Everything else
// here is stateless pattern-matching on text the caller already had.
//
// manifest.json declares no `externally_connectable`, so a web page cannot reach
// this listener today, and that is the real protection. This is the second lock:
// before 2026-08-03 the sender was not examined at ALL (it was read once, for a
// tab id), so the day someone adds externally_connectable — or a content script
// on one of the four matched origins is compromised — the ledger reads out to
// whoever asks and clears with no confirmation. Only the popup needs these.
const PRIVILEGED_TYPES = new Set([
  'helmion:ledger',
  'helmion:ledger-export',
  'helmion:ledger-clear',
  'helmion:guard-upload',
  'helmion:guard-upload-settings',
]);

function isFromOwnPopup(sender) {
  if (!sender || sender.tab) return false;
  if (sender.id !== chrome.runtime.id) return false;
  try {
    return String(sender.url || '').startsWith(chrome.runtime.getURL('popup/'));
  } catch {
    // getURL unavailable. Fail CLOSED — an unverifiable sender does not get the
    // ledger. A safety tool's evidence log is the last thing to hand out on a
    // maybe.
    return false;
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  try {
    const type = message && message.type;

    if (PRIVILEGED_TYPES.has(type) && !isFromOwnPopup(sender)) {
      console.warn('[Helmion Guard] refused a privileged ledger message from an unexpected sender:', type);
      sendResponse({ ok: false, error: 'this message is only accepted from the extension popup' });
      return false;
    }

    if (type === 'helmion:scan') {
      const results = scanBlocks(message.blocks || []);
      sendResponse({ ok: true, results });
      return false;
    }

    if (type === 'helmion:claims') {
      const results = scanProse(message.passages || []);
      sendResponse({ ok: true, results });
      return false;
    }

    // ─── THE DURABLE LEDGER ─────────────────────────────────────────────────
    //
    // These are async, so each returns TRUE to keep the message channel open —
    // the one Chrome MV3 rule that silently breaks a handler if you forget it.
    // Every path settles sendResponse exactly once, including on failure: a
    // ledger write that fails must say so, not leave the caller waiting.
    if (type === 'helmion:log') {
      const entry = makeEntry(message.entry || {});
      appendEntry(ledger, entry)
        .then((result) => sendResponse({ ok: true, ...result }))
        .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
      return true;
    }

    if (type === 'helmion:ledger') {
      readLedger(ledger)
        .then((entries) => sendResponse({ ok: true, entries }))
        .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
      return true;
    }

    if (type === 'helmion:ledger-stats') {
      ledgerStats(ledger)
        .then((stats) => sendResponse({ ok: true, stats }))
        .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
      return true;
    }

    if (type === 'helmion:ledger-export') {
      exportBundle(ledger)
        .then((bundle) => sendResponse({ ok: true, bundle }))
        .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
      return true;
    }

    if (type === 'helmion:ledger-clear') {
      clearLedger(ledger)
        .then(() => sendResponse({ ok: true }))
        .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
      return true;
    }

    // ─── OPT-IN CLOUD UPLOAD ────────────────────────────────────────────────
    //
    // Disabled by default. The popup settings UI is the only caller. See
    // background/upload.js for the full explanation and the warning that this
    // needs Troy's manual browser testing.
    if (type === 'helmion:guard-upload-settings') {
      const payload = message.settings || {};
      const isWrite = Object.prototype.hasOwnProperty.call(payload, 'enabled')
        || Object.prototype.hasOwnProperty.call(payload, 'deviceToken');
      const done = isWrite
        ? setUploadSettings(ledger, { enabled: payload.enabled, deviceToken: payload.deviceToken })
        : getUploadSettings(ledger);
      done
        .then((settings) => sendResponse({ ok: true, settings }))
        .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
      return true;
    }

    if (type === 'helmion:guard-upload') {
      getUploadSettings(ledger)
        .then((settings) => {
          if (!settings.enabled) { sendResponse({ ok: true, skipped: 'not-enabled' }); return; }
          return uploadNewFindings(ledger).then((result) => sendResponse({ ok: true, ...result }));
        })
        .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
      return true;
    }

    if (type === 'helmion:badge') {
      setBadge(sender && sender.tab ? sender.tab.id : undefined, message);
      sendResponse({ ok: true });
      return false;
    }

    if (type === 'helmion:status') {
      latestStatus = {
        protection: ['active', 'limited', 'needs-attention'].includes(message.protection)
          ? message.protection : 'unknown',
        claims: ['active', 'limited', 'unavailable'].includes(message.claims)
          ? message.claims : 'unknown',
      };
      sendResponse({ ok: true });
      return false;
    }

    if (type === 'helmion:guard-status') {
      sendResponse({ ok: true, status: latestStatus });
      return false;
    }

    sendResponse({ ok: false, error: `unknown message type: ${String(type)}` });
    return false;
  } catch (error) {
    // The content script turns this into a banner on the page. It never gets
    // swallowed here, because a check that failed silently is the failure mode
    // this whole extension exists to avoid.
    sendResponse({ ok: false, error: error && error.message ? error.message : String(error) });
    return false;
  }
});
